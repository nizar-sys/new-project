<!DOCTYPE html>
<html>
<head>
	<title>Pembandingan Nilai</title>
</head>
<body>

	<form method="post">
		<tr>
			<input type="number" name="nilaiA" autocomplete="off" placeholder="Nilai A">
			<th>VS</th>
			<input type="number" name="nilaiB" autocomplete="off" placeholder="Nilai B">
		</tr><br>
		<tr>
			<td><input type="submit" name="hitung" value="Cek!"></td>
		</tr>
	</form>
	

	<?php 

	 if (isset($_POST['hitung'])) {
	 	$nilaiA = $_POST['nilaiA'];
	 	$nilaiB = $_POST['nilaiB'];

	 	if ($nilaiA > $nilaiB) {
	 		echo $nilaiA . " lebih besar dari " . $nilaiB . "<br>";
	 		echo "jadi nilai A lebih besar dari nilai B";
	 	}elseif ($nilaiA < $nilaiB) {
	 		echo $nilaiB . " lebih besar dari " . $nilaiA . "<br>";
	 		echo "jadi nilai B lebih besar dari nilai A";
	 	}else{
	 		echo "Nilai SERI";
	 	}
	 	
	 }

	 ?>

</body>
</html>