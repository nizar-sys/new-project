<!DOCTYPE html>
<html>
<head>
	<title>Fotokopi</title>
</head>
<body>
	<form method="post">
		<table>
			
			<tr>
				<td>Tipe Pelanggan: </td>
				<td></td>
				<td>
					<input type="submit" name="non" value=""> Non Member
					<input type="submit" name="member" value=""> Member
				</td>
			</tr>

			<tr>
				<td>Harga Fotocopy Rp: </td>
				<td></td>
				<td><input type="text" name="harga" value="
				<?php

				if (isset($_POST['non'])) {
					echo "100";		
				}
				elseif (isset($_POST['member'])) {
					echo "85";		
				}

				?>">
				</td>
				
			</tr>

			<tr>
				<td>Jumlah Fotocopy: </td>
				<td></td>
				<td><input type="text" name="jumlah"></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
				<td><input type="submit" name="hitung" value="Hitung"></td>
			</tr>

		</table>
	</form>

	<?php 

	if (isset($_POST['hitung'])) {
		$harga = @$_POST['harga'];
		$jumlah = @$_POST['jumlah'];
		$total = $harga * $jumlah;

			echo "Harga total Rp." . $total;
		}

	 ?>

</body>
</html>