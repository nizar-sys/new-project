<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<form method="post">
	<center>
		Kapan kamu lahir ?<input type="text" name="tanggal" name="hari" name="bulan" name="tahun"><br>
		<br><br><input type="submit" name="pecahkan" value="Pecahkan"><br><br>
	<?php
		if (isset($_POST['pecahkan'])) {
				$tanggal = $_POST['tanggal'];
				$split = explode(" - ", $tanggal);
				$hari = $split[0];
				$bulan = $split[1];
				$tahun = $split[2];
		}
	?>
	<table>
		<tr>
			<td>Tanggal<input type="text" name="hari" value="
				<?php
				if(empty($_POST['tanggal'])){}
				else{
					echo $hari; 
				}
				?>">
			</td>

			<td>Bulan<input type="text" name="bulan" value="
				<?php
				if(empty($_POST['tanggal'])){}
				else{
					echo $bulan; 
				}
				?>">
			</td>

			<td>Tahun<input type="text" name="tahun" value="
				<?php
				if(empty($_POST['tanggal'])){}
				else{
					echo $tahun; 
				}
				?>">
			</td>
		</tr>
	</table>
	</center>
</form>
</body>
</html>